// Project:	Atlas
// Entity	Global Functions
// File		globals_fns.h
// Date:	Jan 2012

// Units are declared here to allow forward references between
// them. HASE automatically declares them from the .edl file, but in
// sequence, only allowing backward references.

class clock;
class acc;
class b_arith;
class b_store;
class control;
class distributer;
class pars;
class f_store;
class s_store;
class c_store;
class d_store;
class counter;


int pow(int, int);  // forms exponential without using doubles

char* get_text(t_atlas_instrn Inst);

char* get_A_function(t_atlas_instrn Inst);

char* get_B_function(t_atlas_instrn Inst);

int B_instrn(t_atlas_instrn Inst);

int fetch_Ba(t_atlas_instrn Inst);

int Bm_incrmnt(t_atlas_instrn Inst);


