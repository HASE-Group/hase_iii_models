int is_a_fn(t_atlas_instrn PIE)
{
 if (PIE.function == t_atlas_instrn::B100)
 return 1;
 return 0;
}

char* get_text (t_atlas_instrn Inst)
{
 if (Inst.function == t_atlas_instrn::A314)
   {return "am=s";}
 if (Inst.function == t_atlas_instrn::A315)
   {return "am=-s";}
 if (Inst.function == t_atlas_instrn::A320)
   {return "am=am+s";}
 if (Inst.function == t_atlas_instrn::A321)
   {return "am=am-s";}
 if (Inst.function == t_atlas_instrn::A322)
   {return "am=s-am";}
 if (Inst.function == t_atlas_instrn::A346)
   {return "s=am,a=0";}
 if (Inst.function == t_atlas_instrn::A356)
   {return "s=am";}
 if (Inst.function == t_atlas_instrn::A362)
   {return "am=am*s";}
 if (Inst.function == t_atlas_instrn::A363)
   {return "am=-am*s";}
 if (Inst.function == t_atlas_instrn::A374)
   {return "am=am/s";}
   
 if (Inst.function == t_atlas_instrn::B100)
   {return "b=s-b";}
 else if (Inst.function == t_atlas_instrn::B101)
   {return "b=s";}
 else if (Inst.function == t_atlas_instrn::B102)
   {return "b=b-s";}
 else if (Inst.function == t_atlas_instrn::B103)
   {return "b=-s";}
 else if (Inst.function == t_atlas_instrn::B104)
   {return "b=b+s";}
 else if (Inst.function == t_atlas_instrn::B105)
   {return "b=(64b)+s";}
 else if (Inst.function == t_atlas_instrn::B106)
   {return "b=bXs";}
 else if (Inst.function == t_atlas_instrn::B107)
   {return "b=b&s";}
 else if (Inst.function == t_atlas_instrn::B143)
   {return "b=(b/2)-s";}
 else if (Inst.function == t_atlas_instrn::B147)
   {return "b=bvs";}

 else if (Inst.function == t_atlas_instrn::B110)
   {return "s=s-b";}
 else if (Inst.function == t_atlas_instrn::B111)
   {return "s=-b";}
 else if (Inst.function == t_atlas_instrn::B112)
   {return "s=b-s";}
 else if (Inst.function == t_atlas_instrn::B113)
   {return "s=b";}
 else if (Inst.function == t_atlas_instrn::B114)
   {return "s=b+s";}
 else if (Inst.function == t_atlas_instrn::B116)
   {return "s=sXb";}
 else if (Inst.function == t_atlas_instrn::B117)
   {return "s=b&s";}

 else if (Inst.function == t_atlas_instrn::B120)
   {return "b=n-b";}
 else if (Inst.function == t_atlas_instrn::B121)
   {return "b=n";}
 else if (Inst.function == t_atlas_instrn::B122)
   {return "b=b-n";}
 else if (Inst.function == t_atlas_instrn::B123)
   {return "b=-n";}
 else if (Inst.function == t_atlas_instrn::B124)
   {return "b=b+n";}
 else if (Inst.function == t_atlas_instrn::B125)
   {return "b=(64b)+n";}
 else if (Inst.function == t_atlas_instrn::B126)
   {return "b=bXn";}
 else if (Inst.function == t_atlas_instrn::B127)
   {return "b=b&n";}
 else if (Inst.function == t_atlas_instrn::B163)
   {return "b=(b/2)-n";}
 else if (Inst.function == t_atlas_instrn::B164)
   {return "b=b+(bm&n)";}
 else if (Inst.function == t_atlas_instrn::B165)
   {return "b=bm&n";}
 else if (Inst.function == t_atlas_instrn::B167)
   {return "b=bvn";}

 else if (Inst.function == t_atlas_instrn::B150)
   {return "bt=s-b";}
 else if (Inst.function == t_atlas_instrn::B152)
   {return "bt=b-s";}
 else if (Inst.function == t_atlas_instrn::B170)
   {return "bt=n-b";}
 else if (Inst.function == t_atlas_instrn::B172)
   {return "bt=b-n";}

 else if (Inst.function == t_atlas_instrn::B200)
   {return "if_bm/=0,ba=n,bm+1";}
 else if (Inst.function == t_atlas_instrn::B201)
   {return "if_bm/=0,ba=n,bm+2";}
 else if (Inst.function == t_atlas_instrn::B202)
   {return "if_bm/=0,ba=n,bm-1";}
 else if (Inst.function == t_atlas_instrn::B203)
   {return "if_bm/=0,ba=n,bm-2";}
   
 else if (Inst.function == t_atlas_instrn::B210)
   {return "if_bm_odd,ba=n";}
 else if (Inst.function == t_atlas_instrn::B211)
   {return "bm_even,ba=n";}

 else if (Inst.function == t_atlas_instrn::B214)
   {return "if_bm=0,ba=n";}
 else if (Inst.function == t_atlas_instrn::B215)
   {return "if_bm/=0,ba=n";}
 else if (Inst.function == t_atlas_instrn::B216)
   {return "if_bm>=0,ba=n";}
 else if (Inst.function == t_atlas_instrn::B217)
   {return "if_bm<0,ba=n";}

 else if (Inst.function == t_atlas_instrn::B220)
   {return "if_bt/=0,ba=n,bm+1";}
 else if (Inst.function == t_atlas_instrn::B221)
   {return "if_bt/=0,ba=nbm+2";}
 else if (Inst.function == t_atlas_instrn::B222)
   {return "if_bt/=0,ba=n,bm-1";}
 else if (Inst.function == t_atlas_instrn::B223)
   {return "if_bt/=0,ba=n,bm-2";}

 else if (Inst.function == t_atlas_instrn::B224)
   {return "if_bt=0,ba=n";}
 else if (Inst.function == t_atlas_instrn::B225)
   {return "if_bt/=0,ba=n";}
 else if (Inst.function == t_atlas_instrn::B226)
   {return "if_bt>=0,ba=n";}
 else if (Inst.function == t_atlas_instrn::B227)
   {return "if_bt<0,ba=n";}
 else if (Inst.function == t_atlas_instrn::E1302)
   {return "ba=ba*bm";}
 else if (Inst.function == t_atlas_instrn::E1121)
   {return "b_init";}

 else if (Inst.function == t_atlas_instrn::E1064)
   {return "print nl";}
 else if (Inst.function == t_atlas_instrn::E1067)
   {return "print ba";}

 else
   {return "---------";}
}

char* get_A_function (t_atlas_instrn Inst)
{
 if (Inst.function == t_atlas_instrn::A314)
   {return "LD";}
 if (Inst.function == t_atlas_instrn::A315)
   {return "LDN";}
 if (Inst.function == t_atlas_instrn::A320)
   {return "ADD";}
 if (Inst.function == t_atlas_instrn::A321)
   {return "SUB";}
 if (Inst.function == t_atlas_instrn::A322)
   {return "RSUB";}
 if (Inst.function == t_atlas_instrn::A346)
   {return "STOZ";}
 if (Inst.function == t_atlas_instrn::A356)
   {return "STO";}
 if (Inst.function == t_atlas_instrn::A362)
   {return "MUL";}
 if (Inst.function == t_atlas_instrn::A363)
   {return "MULN";}
 if (Inst.function == t_atlas_instrn::A374)
   {return "DIV";}

 else
   {return "-------";}
}


char* get_B_function (t_atlas_instrn Inst)
{
 if (Inst.function == t_atlas_instrn::B100)
   {return "RSUB";}
 else if (Inst.function == t_atlas_instrn::B101)
   {return "ADD";}
 else if (Inst.function == t_atlas_instrn::B102)
   {return "SUB";}
 else if (Inst.function == t_atlas_instrn::B103)
   {return "SUB";}
 else if (Inst.function == t_atlas_instrn::B104)
   {return "ADD";}
 else if (Inst.function == t_atlas_instrn::B105)
   {return "SHL";}
 else if (Inst.function == t_atlas_instrn::B106)
   {return "XOR";}
 else if (Inst.function == t_atlas_instrn::B107)
   {return "AND";}
 else if (Inst.function == t_atlas_instrn::B143)
   {return "SHR";}
 else if (Inst.function == t_atlas_instrn::B147)
   {return "OR";}

 else if (Inst.function == t_atlas_instrn::B110)
   {return "RSUB";}
 else if (Inst.function == t_atlas_instrn::B111)
   {return "RSUB";}
 else if (Inst.function == t_atlas_instrn::B112)
   {return "SUB";}
 else if (Inst.function == t_atlas_instrn::B113)
   {return "ADD";}
 else if (Inst.function == t_atlas_instrn::B114)
   {return "ADD";}
 else if (Inst.function == t_atlas_instrn::B116)
   {return "XOR";}
 else if (Inst.function == t_atlas_instrn::B117)
   {return "AND";}

 else if (Inst.function == t_atlas_instrn::B120)
   {return "RSUB";}
 else if (Inst.function == t_atlas_instrn::B121)
   {return "ADD";}
 else if (Inst.function == t_atlas_instrn::B122)
   {return "SUB";}
 else if (Inst.function == t_atlas_instrn::B123)
   {return "SUB";}
 else if (Inst.function == t_atlas_instrn::B124)
   {return "ADD";}
 else if (Inst.function == t_atlas_instrn::B125)
   {return "SHL";}
 else if (Inst.function == t_atlas_instrn::B126)
   {return "XOR";}
 else if (Inst.function == t_atlas_instrn::B127)
   {return "AND";}
 else if (Inst.function == t_atlas_instrn::B163)
   {return "SHR";}
 else if (Inst.function == t_atlas_instrn::B164)
   {return "ADD";}
 else if (Inst.function == t_atlas_instrn::B165)
   {return "ADD";}
 else if (Inst.function == t_atlas_instrn::B167)
   {return "OR";}

 else if (Inst.function == t_atlas_instrn::B150)
   {return "RCMP";}
 else if (Inst.function == t_atlas_instrn::B152)
   {return "CMP";}
 else if (Inst.function == t_atlas_instrn::B170)
   {return "RCMP";}
 else if (Inst.function == t_atlas_instrn::B172)
   {return "CMP";}
   
 else if (Inst.function == t_atlas_instrn::E1121)
   {return "INIT";}
 else if (Inst.function == t_atlas_instrn::E1302)
   {return "MUL";}
 else if (Inst.function == t_atlas_instrn::E1064)
   {return "ADD";}
 else if (Inst.function == t_atlas_instrn::E1067)
   {return "ADD";}

 else
   {return "-------";}
}

int B_instrn(t_atlas_instrn Inst)
 {
  if (   Inst.decode_BtoB()
      || Inst.decode_BtoS()
      || Inst.decode_LtoB()
      || Inst.decode_BTS()
      || Inst.decode_BTL()
	 )
  return 1;
return 0;
 }

int fetch_Ba(t_atlas_instrn Inst)
 {
  if (   Inst.function == t_atlas_instrn::B100
	  || Inst.function == t_atlas_instrn::B102
	  || Inst.function == t_atlas_instrn::B104
	  || Inst.function == t_atlas_instrn::B105
	  || Inst.function == t_atlas_instrn::B106
	  || Inst.function == t_atlas_instrn::B107	
	  || Inst.function == t_atlas_instrn::B143
	  || Inst.function == t_atlas_instrn::B147

	  || Inst.function == t_atlas_instrn::B110
	  || Inst.function == t_atlas_instrn::B111
	  || Inst.function == t_atlas_instrn::B112
	  || Inst.function == t_atlas_instrn::B113
	  || Inst.function == t_atlas_instrn::B114
	  || Inst.function == t_atlas_instrn::B115
	  || Inst.function == t_atlas_instrn::B116
	  || Inst.function == t_atlas_instrn::B117
	  
	  || Inst.function == t_atlas_instrn::B120
	  || Inst.function == t_atlas_instrn::B122
	  || Inst.function == t_atlas_instrn::B124
	  || Inst.function == t_atlas_instrn::B125
	  || Inst.function == t_atlas_instrn::B126
	  || Inst.function == t_atlas_instrn::B127
	  || Inst.function == t_atlas_instrn::B163
	  || Inst.function == t_atlas_instrn::B164
	  || Inst.function == t_atlas_instrn::B167
	  
	  || Inst.function == t_atlas_instrn::B150
	  || Inst.function == t_atlas_instrn::B152
	  || Inst.function == t_atlas_instrn::B170
	  || Inst.function == t_atlas_instrn::B172

	  || Inst.function == t_atlas_instrn::E1302
	  || Inst.function == t_atlas_instrn::E1064
	  || Inst.function == t_atlas_instrn::E1067

	 )
  return 1;
return 0;
}

int Bm_incrmnt(t_atlas_instrn Inst)
 {
  if (  Inst.function == t_atlas_instrn::B200
     || Inst.function == t_atlas_instrn::B220)
  {return 1;}
  else if (Inst.function == t_atlas_instrn::B201
	    || Inst.function == t_atlas_instrn::B221)
  {return 2;}
  else if (Inst.function == t_atlas_instrn::B202
        || Inst.function == t_atlas_instrn::B222)
  {return -1;}
  else if (Inst.function == t_atlas_instrn::B203
        || Inst.function == t_atlas_instrn::B223)
  {return -2;}
  else
   {return 0;}
}

